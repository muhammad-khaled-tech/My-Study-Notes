# Admin II – Lecture 1: Comprehensive Study Guide
*Topics: Boot Sequence • systemd • Scheduling • Logging • Networking*

---

## 1. The Linux Boot Sequence

Understanding the boot process is critical for troubleshooting startup problems.

| Stage | Component | Responsibility |
|-------|-----------|----------------|
| 1 | BIOS | Runs POST, detects hardware, loads MBR |
| 2 | MBR | First 512 bytes of boot drive; loads GRUB2 |
| 3 | GRUB2 | Boot loader; loads kernel (vmlinuz) and initramfs |
| 4 | initramfs | Temporary root FS; loads drivers needed to mount real root |
| 5 | Kernel | Starts systemd (PID 1) |
| 6 | systemd | Reads default.target; brings system to desired state |

> 🔑 **Key Point:** The MBR is only 512 bytes: 446 bytes for bootloader code, 64 bytes for the partition table, and 2 bytes for the "magic number" (error detection).

---

### GRUB2 Key Files

- `/boot/grub2/grub.cfg` — **Never edit directly** — this is auto-generated
- `/etc/default/grub` — **Edit this file** to configure GRUB2 options
- After editing `/etc/default/grub`, always run:
  ```bash
  grub2-mkconfig -o /boot/grub2/grub.cfg
  ```

**Key parameters in `/etc/default/grub`:**

| Parameter | Description | Example |
|-----------|-------------|---------|
| `GRUB_TIMEOUT` | How long GRUB menu displays (seconds) | `GRUB_TIMEOUT=5` |
| `GRUB_DEFAULT` | Which menu entry to boot by default | `GRUB_DEFAULT=saved` |
| `GRUB_CMDLINE_LINUX` | Extra kernel command line options | `GRUB_CMDLINE_LINUX="rhgb quiet"` |

---

### initramfs & dracut

- **initramfs** is a temporary, memory-based file system mounted before the real root.
- It pre-loads block device modules (IDE, SCSI, RAID) so the real root FS can be accessed.
- The **dracut** utility creates/rebuilds initramfs whenever a new kernel is installed.
- View initramfs contents with: `lsinitrd`

---

## 2. systemd & Target Units

`systemd` is the parent of all processes (PID 1). It replaces the older SysVinit and Upstart systems.

### Target Units (Run Levels)

| Run Level | systemd Target | Description |
|-----------|----------------|-------------|
| 0 | `poweroff.target` | Shut down and power off |
| 1 | `rescue.target` | Single-user rescue shell |
| 2, 3, 4 | `multi-user.target` | Non-graphical multi-user shell |
| 5 | `graphical.target` | Graphical multi-user (GUI) |
| 6 | `reboot.target` | Shut down and reboot |

### Key systemd Commands

| Task | Command |
|------|---------|
| View default target | `systemctl get-default` |
| Set default target | `systemctl set-default multi-user.target` |
| Switch to target (now) | `systemctl isolate multi-user.target` |
| Start a service | `systemctl start postfix` |
| Stop a service | `systemctl stop postfix` |
| Restart a service | `systemctl restart postfix` |
| Check service status | `systemctl status postfix` |
| Enable at boot | `systemctl enable postfix` |
| Disable at boot | `systemctl disable postfix` |
| List all service units | `systemctl list-unit-files --type service` |
| List active units | `systemctl list-units --type=service` |

> 🔑 **Key Point:** `systemctl set-default` changes the permanent default. `systemctl isolate` changes the current running target **without rebooting**.

---

## 3. Task Scheduling (cron & at)

### at — One-Time Task Execution

- Managed by the `atd` daemon.
- Controlled by `/etc/at.allow` and `/etc/at.deny`.
- Schedule a job: `at 14:30`
- List scheduled jobs: `atq`
- Remove a scheduled job: `atrm <job_id>`

### cron — Recurring Task Execution

- Managed by the `crond` daemon.
- User crontabs stored in: `/var/spool/cron/`
- System crontab: `/etc/crontab` and `/etc/cron.d/`
- Edit crontab: `crontab -e`
- View crontab: `crontab -l`
- Remove crontab: `crontab -r`

### Crontab Format

```
MIN  HOUR  DOM  MON  DOW  command
```

| Field | Values | Example |
|-------|--------|---------|
| Minute | 0–59 | `30` = at 30 minutes past |
| Hour | 0–23 | `8` = 8:00 AM |
| Day of Month | 1–31 | `*` = every day |
| Month | 1–12 | `*` = every month |
| Day of Week | 0–6 (Sun=0) | `1` = Monday |
| Command | Any shell command | `/usr/bin/vmstat` |

**Special syntax:**
- `*/20` — every 20 minutes
- `1,2` — January and February
- `5-10` — values from 5 to 10
- `@daily`, `@weekly`, `@monthly`, `@reboot` — special strings

**Example** — log system stats every 10 min, 8 AM to 5 PM:
```bash
*/10 8-17 * * * /usr/bin/vmstat >> /var/log/perf.log
```

> 🔑 **Key Point:** By default, cron emails output to the user specified by `MAILTO` in crontab. Set `MAILTO=manager` to redirect to another user.

---

## 4. Managing System Logs (rsyslog)

### rsyslog Overview

- The `rsyslogd` daemon handles system logging.
- Configuration file: `/etc/rsyslog.conf`
- Generate manual log messages with: `logger 'your message'`

### Selector Format

Each rule: `facility.severity   action`

**Facilities:**

| Facility | Meaning |
|----------|---------|
| `kern` | Kernel messages |
| `mail` | Mail system |
| `daemon` | System daemons |
| `cron` | Cron/at messages |
| `local0–local7` | Custom local use |
| `*` | All facilities |

**Severity Levels (High → Low):**

| Severity | Meaning |
|----------|---------|
| `emerg` | System is unusable |
| `alert` | Action must be taken immediately |
| `crit` | Critical conditions |
| `err` | Error conditions |
| `warning` | Warning conditions |
| `notice` | Normal but significant |
| `info` | Informational messages |
| `debug` | Debug-level messages |

### Centralized Logging Setup

**Logging Server** — edit `/etc/rsyslog.conf`:
```bash
$ModLoad imudp
$UDPServerRun 514
```

**Workstation** — add forwarding rule in `/etc/rsyslog.conf`:
```bash
*.* @<server_ip>:514      # UDP  (use @@ for TCP)
```

**To prevent messages from also writing locally**, add the discard action:
```bash
*.* @<server_ip>:514
& ~
```

> 🔑 **Key Point:** Messages appear on the workstation's `/var/log/messages` because rsyslog processes logs locally first. The `& ~` discard action prevents local writing after forwarding.

---

## 5. Network Configuration

### Key Networking Commands

| Task | Command |
|------|---------|
| Show all interfaces (active) | `ip addr show` / `ifconfig` |
| Show ALL interfaces (incl. down) | `ip addr show` / `ifconfig -a` |
| Show MAC address | `ip link show` / `ifconfig -a \| grep ether` |
| Bring interface down | `ip link set eth0 down` / `ifdown eth0` |
| Bring interface up | `ip link set eth0 up` / `ifup eth0` |
| Show routing table | `ip route show` / `route -n` |
| NM connection reload | `nmcli con reload` |
| Set static IP via NM | `nmcli con mod eth0 ipv4.addresses 192.168.1.10/24` |
| Set dynamic IP via NM | `nmcli con mod eth0 ipv4.method auto` |
| Text-based NM UI | `nmtui` |

### Static IP Config File

Location: `/etc/sysconfig/network-scripts/ifcfg-<interface>`

| Parameter | Value |
|-----------|-------|
| `BOOTPROTO` | `none` |
| `IPADDR` | `192.168.1.100` |
| `NETMASK` | `255.255.255.0` |
| `GATEWAY` | `192.168.1.1` |
| `DNS1` | `8.8.8.8` |
| `ONBOOT` | `yes` |

### Dynamic IP

```bash
# In config file:
BOOTPROTO=dhcp

# Or via NetworkManager:
nmcli con mod eth0 ipv4.method auto
nmcli con up eth0
```

### IP Aliasing (Multiple IPs on One Interface)

Create additional config files: `ifcfg-eth0:1`, `ifcfg-eth0:2`, etc., each with a unique `DEVICE` and `IPADDR`. Bring each alias up with `ifup eth0:1`.

### Hostname Configuration

```bash
hostnamectl set-hostname newhostname
# Or edit: /etc/hostname
# Also update /etc/hosts to match
```

---

## Quick Reference Card

### systemd
```bash
systemctl {start|stop|restart|status|enable|disable} <service>
systemctl {get-default|set-default|isolate} <target>
systemctl list-units --type=service
```

### GRUB2
```bash
# Edit:       /etc/default/grub
# Regenerate: grub2-mkconfig -o /boot/grub2/grub.cfg
```

### cron
```bash
crontab {-e|-l|-r}
# Format: MIN HOUR DOM MON DOW  command
*/10 8-17 * * *  /usr/bin/vmstat
```

### rsyslog
```bash
# Forward:        *.* @server_ip:514
# Discard locally: & ~
# Test:            logger 'test message'
```

### Networking
```bash
ip addr show / ip link show / ifconfig -a
ip link set eth0 {up|down}
nmcli con mod eth0 ipv4.method {auto|manual}
```
