# Admin II – Lab 1: Answer Key

---

## Part 1: systemd & Services

### Q1. View Status of All System Services
```bash
systemctl list-units --type=service
# Add --all to see inactive units too:
systemctl list-units --type=service --all
```

### Q2. Change Default Run Level to multi-user.target and Reboot
```bash
systemctl set-default multi-user.target
reboot
# Verify after reboot:
systemctl get-default
```

### Q3. Send Mail to root User
```bash
echo 'Test message body' | mail -s 'Test Subject' root
```
> Ensure the `postfix` service is running before sending.

### Q4. Verify Mail Received
```bash
mail
# Or:
cat /var/spool/mail/root
```

### Q5. Stop the postfix Service
```bash
systemctl stop postfix
```

### Q6. Send Mail Again to root (postfix stopped)
```bash
echo 'Test while postfix stopped' | mail -s 'Test 2' root
```

### Q7. Verify Mail Received (postfix stopped)
Mail will fail or be queued locally. Check `/var/spool/mail/root` — the message may not arrive since postfix is stopped.
```bash
mail
```

### Q8. Start the postfix Service
```bash
systemctl start postfix
```

### Q9. Verify Mail Received After Starting postfix
Once postfix restarts, queued messages will be delivered.
```bash
mail
```

---

## Part 2: GRUB2 Bootloader

### Q10. Change GRUB2 Timeout to 20 Seconds
Edit the GRUB default configuration file (**do not edit grub.cfg directly**):
```bash
vi /etc/default/grub
```
Change:
```
GRUB_TIMEOUT=5
```
To:
```
GRUB_TIMEOUT=20
```
Regenerate grub.cfg:
```bash
grub2-mkconfig -o /boot/grub2/grub.cfg
```

### Q11. Change Default Operating System in GRUB2
List available menu entries first:
```bash
awk -F\' '/^menuentry / {print NR-1": ", $2}' /boot/grub2/grub.cfg
```
Edit `/etc/default/grub` and set the index of the desired entry:
```
GRUB_DEFAULT=1
```
Regenerate grub.cfg:
```bash
grub2-mkconfig -o /boot/grub2/grub.cfg
```

---

## Part 3: Scheduling with cron

### Q12. Monitor System Resources Every 10 Minutes (8 AM–5 PM) — Focus on Memory
The lab asks to monitor performance with a focus on **memory**. Edit the root crontab:
```bash
crontab -e
```
Add one of the following (choose based on what you want to capture):

**Option 1 — vmstat (memory, swap, CPU overview):**
```
*/10 8-17 * * * /usr/bin/vmstat >> /var/log/perf_report.log
```

**Option 2 — free (memory and swap usage):**
```
*/10 8-17 * * * /usr/bin/free -h >> /var/log/perf_report.log
```

**Option 3 — sar (detailed memory stats, requires sysstat package):**
```
*/10 8-17 * * * /usr/bin/sar -r >> /var/log/perf_report.log
```

**Option 4 — mail output directly to root:**
```
MAILTO=root
*/10 8-17 * * * /usr/bin/vmstat
```
> `MAILTO=root` is set by default in crontab. When set, cron automatically emails any command output to that address.

### Q13. Check Mail as root for cron Job Output
```bash
mail
```
> Cron sends stdout/stderr to the user defined by `MAILTO` in crontab.

### Q14. Send cron Output to Another Email Address (manager)
Add `MAILTO` at the top of the crontab, or before the specific job:
```
MAILTO=manager
*/10 8-17 * * * /usr/bin/vmstat
```

### Q15. Check Mail as manager User
```bash
su - manager
mail
```

---

## Part 4: Advanced Permissions – /opt/research

### Q16. Set Up Shared Directory with ACLs

**Step 1 — Create directory and set base ownership/permissions:**
```bash
mkdir /opt/research
chown root:grads /opt/research
chmod 3770 /opt/research
```
> `3770` = setgid (new files inherit group `grads`) + sticky; `rwxrws---` for owner+group, no access for others.

**Step 2 — Set ACLs for group profs (read/write) and group interns (read-only):**
```bash
setfacl -m g:profs:rw /opt/research
setfacl -m g:interns:r /opt/research
```

**Step 3 — Set default ACLs so new files inherit the same permissions:**
```bash
setfacl -d -m g:grads:rwx /opt/research
setfacl -d -m g:profs:rw /opt/research
setfacl -d -m g:interns:r /opt/research
setfacl -d -m o::--- /opt/research
```

**Step 4 — Verify:**
```bash
getfacl /opt/research
```

---

## Part 5: Network Configuration

### Q17. Display MAC Address (2 Ways)
```bash
ip link show
ifconfig -a | grep ether
```

### Q18. Display Settings of All Active Interfaces
```bash
ip addr show
# Or:
ifconfig
```

### Q19. Display Settings of ALL Interfaces (Active & Inactive)
```bash
ip addr show
ifconfig -a
```

### Q20. Bring Interface Down
```bash
ip link set eth0 down
# Or:
ifdown eth0
```
> Replace `eth0` with your actual interface name (use `ip link show` to find it).

### Q21. Configure Network Card with Static IP
Edit the interface config file:
```bash
vi /etc/sysconfig/network-scripts/ifcfg-eth0
```
Set:
```
BOOTPROTO=none
IPADDR=192.168.1.100
NETMASK=255.255.255.0
GATEWAY=192.168.1.1
DNS1=8.8.8.8
ONBOOT=yes
```

### Q22. Bring Interface Up
```bash
ip link set eth0 up
# Or:
ifup eth0
```

### Q23. Verify Network Settings with ifconfig
```bash
ifconfig eth0
```

### Q24. Configure Dynamic IP via NetworkManager
```bash
nmcli con mod eth0 ipv4.method auto
nmcli con up eth0
# Or use the TUI:
nmtui
```

### Q25. Check with ifconfig and Config File
```bash
ifconfig eth0
cat /etc/sysconfig/network-scripts/ifcfg-eth0
```

### Q26. Reconfigure with system-config-network for Static IP
```bash
system-config-network
```
> This launches a TUI. Select the interface, choose Static IP, and fill in the details.

### Q27. Configure Interface with 3 IPs (IP Aliasing)
Create alias config files:
```bash
cp /etc/sysconfig/network-scripts/ifcfg-eth0 /etc/sysconfig/network-scripts/ifcfg-eth0:1
vi /etc/sysconfig/network-scripts/ifcfg-eth0:1
```
Set `DEVICE=eth0:1` and a different `IPADDR`. Repeat for `eth0:2`, then:
```bash
ifup eth0:1
ifup eth0:2
ifconfig
```

### Q28. Change Hostname in Global Network File
```bash
hostnamectl set-hostname newhostname
# Or edit directly:
vi /etc/hostname
# Also update /etc/hosts if needed
```

---

## Part 6: Centralized Logging with rsyslogd

### Setup: Logging Server
Edit `/etc/rsyslog.conf` and uncomment/add lines to accept remote messages:
```bash
# For UDP:
$ModLoad imudp
$UDPServerRun 514

# For TCP:
$ModLoad imtcp
$InputTCPServerRun 514
```
Restart rsyslog and open the firewall:
```bash
systemctl restart rsyslog
firewall-cmd --permanent --add-port=514/udp
firewall-cmd --reload
```

### Setup: Workstation
Edit `/etc/rsyslog.conf` and add a forwarding rule:
```bash
*.* @192.168.1.10:514    # UDP  (use @@ for TCP)
```
Restart rsyslog:
```bash
systemctl restart rsyslog
```

### Test with the logger Command
On the workstation, generate a test log message:
```bash
logger 'Test message from workstation'
```

### Q: Does the Message Appear in the Logging Server's /var/log/messages?
Yes — if the setup is correct, the message will appear on the logging server. Verify by watching the log in real time on the server while running `logger` on the workstation:
```bash
# On the logging server:
tail -f /var/log/messages
```
You should see a line like:
```
Feb 26 10:00:01 workstation root: Test message from workstation
```
If it does **not** appear, check:
- Port 514 is open on the server firewall (`firewall-cmd --list-ports`)
- The `imudp`/`imtcp` module is loaded in `/etc/rsyslog.conf` on the server
- rsyslog is restarted on both machines (`systemctl restart rsyslog`)
- SELinux is not blocking: `setsebool -P allow_syslog_remote_auth 1`

### Q: Why Does the Message Also Appear on the Workstation?
Because rsyslog processes messages **locally** before forwarding them. The default `/etc/rsyslog.conf` still logs `*.*` to `/var/log/messages` locally, so messages are written both locally and forwarded to the remote server.

### Q: How to Have Messages Only Appear on the Logging Server?
Use the tilde (`~`) **discard action** after the forwarding rule in the workstation's `/etc/rsyslog.conf`:
```bash
*.* @192.168.1.10:514
& ~
```
> The `& ~` discards the message after forwarding, so it will **not** be written to the local `/var/log/messages`.
